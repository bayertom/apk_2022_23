from PyQt6.QtCore import *
from PyQt6.QtGui import *
from PyQt6.QtWidgets import *

class Draw(QWidget):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        #Query point and polygon
        self.__add_L = True
        self.__L = QPolygonF()
        self.__B = QPolygonF()
        self.__LD = QPolygonF()

        self.__add_vertex = True

    def mousePressEvent(self, e:QMouseEvent):
        #Left mouse button click
        x = e.position().x()
        y = e.position().y()

        #Create new point
        p = QPointF(x, y)

        #Add point to L
        if self.__add_L:
            self.__L.append(p)

        #Add point to B
        else:
            self.__B.append(p)

        #Repaint screen
        self.repaint()

    def paintEvent(self, e:QPaintEvent):
        #Draw polygon

        #Create graphic object
        qp = QPainter(self)

        #Start draw
        qp.begin(self)

        #Set attributes
        qp.setPen(Qt.GlobalColor.blue)

        #Draw L
        qp.drawPolyline(self.__L)

        # Set attributes
        qp.setPen(Qt.GlobalColor.black)

        # Draw B
        qp.drawPolyline(self.__B)

        # Set attributes
        qp.setPen(Qt.GlobalColor.red)

        # Draw LD
        qp.drawPolyline(self.__LD)

        #End draw
        qp.end()

    def switchSource(self):
        #Move point or add vertex
        self.__add_vertex = not(self.__add_vertex)

    def getL(self):
        return self.__L

    def getB(self):
        return self.__B

    def setLD(self, LD_):
        LD = LD_


    def setSource(self, status):
        self.__add_L = status
